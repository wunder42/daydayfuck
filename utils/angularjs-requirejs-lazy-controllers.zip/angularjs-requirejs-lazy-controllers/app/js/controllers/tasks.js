/**
 * Created with IntelliJ IDEA.
 * User: Mateusz
 * Date: 15.11.12
 * Time: 22:38
 */

'use strict';

define([], function () {

    function TasksController($scope) {
        $scope.addCart = function() {
        	console.log('addcart', this);
        	jQuery(".addCart").before("<div class='dragItem'>dragItem5</div>");
        }
    }

    return TasksController;
});
